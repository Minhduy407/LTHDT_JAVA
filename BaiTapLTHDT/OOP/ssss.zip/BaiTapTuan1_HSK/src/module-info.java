/**
 * 
 */
/**
 * 
 */
module BaiTapTuan1_HSK {
	requires java.desktop;
}