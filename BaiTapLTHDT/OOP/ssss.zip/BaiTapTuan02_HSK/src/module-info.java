/**
 * 
 */
/**
 * 
 */
module BaiTapTuan02_HSK {
	requires java.desktop;
}